
[Python_Version](https://github.com/CSUFTitanRover/TitanRover/tree/master2017/GPS/IMU/Python_Version)
==============================================================================================================================

>This program will read the IMU registers and provide one time reading of heading, pitch, roll angles.  Written to function with the Adafruit 10-DOF.  This is written to be a process that is called when information is needed by the Rover system. 

ToDo's
- [ ] - Decide on orientation of chip and finalize the code for proper angles
- [x] - Fix NaN issue between Python and Node.js

==============================================================================================================================



[C_Version](https://github.com/CSUFTitanRover/TitanRover/tree/master2017/GPS/IMU/C_Version)
==============================================================================================================================

>This program will read the IMU registers and provide continuious heading, pitch, roll angles.  Written to function with the Adafruit 10-DOF.

Discontinued after research showing Python to be better language for this project.

==============================================================================================================================


